<link href="<?php echo FR_PLUGIN_URL; ?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo FR_PLUGIN_URL; ?>css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo FR_PLUGIN_URL; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700|Oswald:300,400,700" rel="stylesheet">
<?php $terms = get_terms( array(
				'taxonomy' => 'go-service-cat',
    			'hide_empty' => false,
				));
				//print_r($terms);
	
?>

<div class="container-fluid nopadd">
  <div class="container width1">
    <div class="body-content">
      <div class="form">
        <div id="system-step" class="step1">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h1>You needs to specify your type of  computer?</h1>
              <select id="system-option" class="form-control select-box-new" name="system_type">
                <option selected>-- Select --</option>
                <option id="pc-form" class="pc-type" value="pc">PC(Windows)</option>
                <option id="pc-mac" class="pc-type" value="mac">MAC</option>
              </select>
            </div>
          </div>
        </div>
        <div id="service-category" class="step1 step2">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service Category:</h2>
              <select id="service-category-option" class="form-control select-box-new" >
                <option selected>-- Select --</option>
                <?php
                	foreach($terms as $key=>$term){
						$term_id = $term->term_id;
						$term_name = $term->name;
						$term_slug = $term->slug;
						if(!$term->parent){?>
							<option id="maintenance" class="category" value="<?php echo $term_id;?>"><?php echo $term_name;?></option>
						<?php }
					}
				?>
                <!--<option id="maintenance" value="maintainance">Maintenance</option>
                <option id="setup">Set up</option>
                <option id="trouble-repair">Trouble Repair</option>-->
              </select>
            </div>
          </div>
        </div>
        <div id="service-subcategory1" class="step1 step2">
        </div>
        <div id="service-category-two" class="step1 step2 text-center">
        </div>
        <div id="service-category-four" class="step1 step2 text-center desc">
          <!--<div class="diag-box">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box title-box-one">
                  <h1>Service Rate is $2000</h1>
                  <div class="service-cost-notes">
                    <p>serviceCostNotes will be here...</p>
                  </div>
                  <div class="price">Total Price: <span>$1999</span></div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box title-box-one">
                  <div class="service-cost-notes service-cost-notes2">
                    <p>serviceCostNotes will be here...</p>
                  </div>
                  <a href="#" class="call">03-5728-3576</a> </div>
              </div>
            </div>
          </div>
          <div class="step1 step2">
            <div class="row">
              <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
                <h2>Want to use our Service?</h2>
                <select id="service-select" class="form-control select-box-new">
                  <option>-- Select --</option>
                  <option value="" id="service-select-no">No</option>
                  <option value="http://webqueue.org/samples/projects/sudipta/BUILD-A-WORDPRESS-PLUGIN/html/contact-form.html">Yes</option>
                </select>
              </div>
            </div>
          </div>-->
        </div>
        <div id="service-category-five" class="step1 step2 text-center desc">
          <div class="diag-box">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="txt-bx2">
                	<h3>goodbye</h3>
                    <h4>We hope to see you again.</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<!--<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script> --> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/bootstrap.min.js" type="text/javascript"></script> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/scripts.js"></script> 
<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';
var carryin_onsite = 'onsite';

$("#service-category").hide();
$("#service-subcategory1").hide();
$("#service-category-five").hide();

$(function() {
  $("#system-option").change(function() {
    if ($(".pc-type").is(":selected")) {
      $("#service-category").show();
      $("#client_graph_form").hide();
    } 
	else {
      $("#service-category").hide();
      $("#client_graph_form").show();
    }
  }).trigger('change');
  
});

$(function() {
  $("#service-category").change(function() {
    if ($(".category").is(":selected")) {
	  var pc_type = $(".pc-type:selected").val();
	  var category = $(".category:selected").val();
	  var data = {
			'action' : 'wq_create_subcategory_html',
			'pc_type' : pc_type,
			'category' : category
		};
		$.post(ajaxurl , data , function(response){
			$('#service-subcategory1').html(response);
			//console.log(response);
		});
      $("#service-subcategory1").show();
      $("#client_graph_form").hide();
    } 
	else {
      $("#service-subcategory1").hide();
      $("#client_graph_form").show();
    }
  }).trigger('change');
  
});
$(function() {
  $(document).on("change", "#subcategory-option", function() {
	  
	  var pc_type = $(".pc-type:selected").val();
	  var category = $(".category:selected").val();
	  var sub_category = $(".subcategory1:selected").val();
	  var data = {
			'action' : 'wq_create_service_confirm_html',
			'pc_type' : pc_type,
			'category' : category,
			'sub_category' : sub_category
		};
		
		$.post(ajaxurl , data , function(response){
			
			$('#service-category-two').html(response);
			$("#service-category-two").show();
			//console.log(response);
		});
      //$("#client_graph_form").hide();
  });
  
  $(document).on("change", "#onsite_carryin_select", function() {
	  
	  $(".ocbaserate").hide();
	  $("#"+$(this).val()+"_baserate").show();
	  carryin_onsite = $(this).val();
	  
	  $(".logo-option-post-list").prop('checked', false);
	  $("#service-category-four").hide();
	  //$("input:radio").removeAttr("checked");
  });
  
  $(document).on("click", ".logo-option-post-list", function() {
	  
	if ($(this).is(':checked')) {
		
		var post_id = $(this).val();
		var pc_type = $(".pc-type:selected").val();
		var category = $(".category:selected").val();
		var sub_category = $(".subcategory1:selected").val();
		
		var data = {
			'action' : 'wq_onselect_post_html',
			'pc_type' : pc_type,
			'category' : category,
			'sub_category' : sub_category,
			'carryin_onsite' : carryin_onsite,
			'post_id' : post_id
		};
		
		$.post(ajaxurl , data , function(response){
		
			$('#service-category-four').html(response);
			$("#service-category-four").show();
		});
	}
  });  
});

$(function() {
	$("#service-category-two").change(function() {
		if ($(".service_type_name").is(":selected")) {
			var pc_type = $(".pc-type:selected").val();
	  		var category = $(".category:selected").val();
	  		var sub_category = $(".subcategory1:selected").val();
			var service_type_name = $(".service_type_name:selected").val();
			
			var data = {
				'action' : 'wq_create_service_details_html',
				'pc_type' : pc_type,
				'category' : category,
				'sub_category' : sub_category,
				'service_type_name' : service_type_name
			};
			$.post(ajaxurl , data , function(resp){
				$('#service-details').html(resp);
				console.log(resp);
			});
			$("#service-category-four").show();
			//$("#client_graph_form").hide();
			  
		};
	}).trigger('change');
});

$(document).on("change", "#service-select", function() {
	 var service_select_yn = $(this).val(); 
	 if (service_select_yn == 'yes') {
		var pc_type = $(".pc-type:selected").val();
		var category = $(".category:selected").val();
		var sub_category = $(".subcategory1:selected").val();
		var onsite_carryin = $('#onsite_carryin_select').find(":selected").val();
		var service_name = $('input[name=logo-option]:checked', '#service-name').val();
		var data = {
				'action' : 'wq_save_data_before_email',
				'pc_type' : pc_type,
				'category' : category,
				'sub_category' : sub_category,
				'service_type_name' : onsite_carryin,
				'service_name' : service_name
			};
		$.post(ajaxurl , data , function(resp){
				//var url = '<?php //echo get_permalink(45);?>';
				//for server- below
				var url = '<?php echo $link;?>';
				window.location = url+'&contact-id='+resp;
				//console.log(resp);
			});
	}else{
		 //console.log(service_name);
		$("#service-category-five").show();
		setTimeout(function(){
			
			window.location.replace("<?php echo home_url();?>");
		}, 3000);		
	}
});

</script> 

