<link href="<?php echo FR_PLUGIN_URL; ?>css/style-webq.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700" rel="stylesheet">
<div class="wq_main center-textwq">
<div class="wq_center_wrap">
<div class="wq_main inner-wrapwq lefttext-wq">
<div class="common-wrapwq titlewq-top">
<h1>PC Repair - Set Up - Support Order Form</h1>
<p>(All the information on this form is trasmitted securely through a SSL connection.）</p>
<span class="redwq">*Please fill in all the fields marked with this simbol.</span>
</div>
<div class="common-wrapwq form-wq">
<div class="halfdivwq left-pullwq">
<form id="connectwithus" method="post">
<label class="labelwq">Name<font color="#FF0000">*</font></label>
<input name="" type="text" class="input-wq" id="con_name" placeholder="Enter name">
</div>
<div class="halfdivwq right-pullwq">
<label class="labelwq">Postcode</label>
<input name="" type="text" class="input-wq" id="con_postcode" placeholder="Enter postcode">
</div>
<div class="halfdivwq left-pullwq">
<label class="labelwq">Prefecture<font color="#FF0000">*</font></label>
<select class="input-wq" id="con_prefecture" required>
<option selected="selected" value="">--Select--</option>
<option value="option1">Option 1</option>
<option value="option2">Option 2</option>
<option value="option3">Option 3</option>
<option value="option4">Option 4</option>
</select>
</div>
<div class="halfdivwq right-pullwq">
<label class="labelwq">Building</label>
<input name="" type="text" class="input-wq" id="con_building" placeholder="Enter building">
</div>
<div class="fulldivwq right-pullwq">
<label class="labelwq">Address<font color="#FF0000">*</font></label>
<input name="" type="text" class="input-wq" id="con_address" placeholder="Enter address">
</div>
<div class="halfdivwq left-pullwq">
<label class="labelwq">Phone</label>
<input name="" type="text" class="input-wq" id="con_phone" placeholder="Enter phone">
</div>
<div class="halfdivwq right-pullwq">
<label class="labelwq">E-mail<font color="#FF0000">*</font></label>
<input name="" type="email" class="input-wq" id="con_email" placeholder="Enter e-mail">
</div>
<div class="halfdivwq right-pullwq">
<label class="labelwq">Desired Day</label>
<input name="" type="text" class="input-wq" id="con_dday" placeholder="Enter day">
</div>
<div class="halfdivwq left-pullwq">
<label class="labelwq">Desired Time</label>
<!--<input name="" type="text" class="input-wq" id="con_dtime" placeholder="Enter time">-->
<select class="input-wq" id="con_dtime">
<option selected="selected" value="">--Select--</option>
<option value="9.00 AM">9.00 AM</option>
<option value="9.30 AM">9.30 AM</option>
<option value="10.00 AM">10.00 AM</option>
<option value="10.30 AM">10.30 AM</option>
<option value="11.00 AM">11.00 AM</option>
<option value="11.30 AM">11.30 AM</option>
<option value="12.00 PM">12.00 PM</option>
<option value="12.30 PM">12.30 PM</option>
<option value="1.00 PM">1.00 PM</option>
<option value="1.30 PM">1.30 PM</option>
<option value="2.00 PM">2.00 PM</option>
<option value="2.30 PM">2.30 PM</option>
<option value="3.00 PM">3.00 PM</option>
<option value="3.30 PM">3.30 PM</option>
<option value="4.00 PM">4.00 PM</option>
<option value="4.30 PM">4.30 PM</option>
<option value="5.00 PM">5.00 PM</option>
<option value="5.30 PM">5.30 PM</option>
<option value="6.00 PM">6.00 PM</option>
<option value="6.30 PM">6.30 PM</option>
<option value="7.00 PM">7.00 PM</option>
<option value="7.30 PM">7.30 PM</option>
<option value="8.00 PM">8.00 PM</option>
<option value="8.30 PM">8.30 PM</option>
<option value="9.00 PM">9.00 PM</option>
<option value="9.30 PM">9.30 PM</option>
</select>

</div>
<div class="fulldivwq left-pullwq">
<span class="left-pullwq common-wrapwq check-tandc"><input type="checkbox" id="cnf"><a href="#" class="left-pullwq term-link" onClick="pop('popDivwq')">
I Agree with this Terms & Conditions</a></span>
<button type="submit" class="submitwq contact_submit">Submit Now</button>
<button type="button" class="resetwq">Reset Now</button>
<div id="show_mssg"> </div>
</form>
</div>
</div>
</div>
</div>
</div>
<div id="popDivwq" class="ontopwq">
<div id="popupwq">
<a href="#" class="hidewq" onClick="hide('popDivwq')">X</a>
<?php echo get_option('terms_and_condition'); ?>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/bootstrap.min.js" type="text/javascript"></script> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/scripts.js"></script> 
<script type="text/javascript">
			function pop(div) {
				document.getElementById(div).style.display = 'block';
			}
			function hide(div) {
				document.getElementById(div).style.display = 'none';
			}
			//To detect escape button
			document.onkeydown = function(evt) {
				evt = evt || window.event;
				if (evt.keyCode == 27) {
					hide('popDiv');
				}
			};
</script>

<script type="text/javascript">
	$(document).ready(function(){
		var order_name 		= $('#con_name').val(); 
		var order_postcode 	= $('#con_postcode').val();
		var order_prefecture= $("#con_prefecture:selected").val();
		var order_building 	= $('#con_building').val();
		var order_address 	= $('#con_address').val();
		var order_phone 	= $('#con_phone').val();
		var order_email 	= $('#con_email').val();
		var order_dday 		= $('#con_dday').val();
		var order_dtime 	= $('#con_dtime:selected').val();
		var cnf             = $('#cnf').is(':checked'); 
		var contact_id		= '<?php echo $_GET['contact-id'];?>';
		var filter_phone_no = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
		var filter_email 	= /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var error = false;
		
		$(document).on('submit','#connectwithus',function(e){
			e.preventDefault();
			
			error = false;
			order_name 		= $('#con_name').val(); 
			order_postcode 	= $('#con_postcode').val();
			order_prefecture= $("#con_prefecture option:selected").val();
			order_prefecture_text= $("#con_prefecture option:selected").text();
			order_building 	= $('#con_building').val();
			order_address 	= $('#con_address').val();
			order_phone 	= $('#con_phone').val();
			order_email 	= $('#con_email').val();
			order_dday 		= $('#con_dday').val();
			order_dtime 	= $('#con_dtime option:selected').val();
			if(order_name){
				 $('#con_name').removeClass("invalid");
			}else{
			   $('#con_name').addClass("invalid");
			   error = true;
			}
			if(order_address){
				 $('#con_address').removeClass("invalid");
			}else{
			   $('#con_address').addClass("invalid");
			   error = true;
			}
			if(order_phone){
				if(filter_phone_no.test(order_phone)){
					$('#con_phone').removeClass("invalid");
				}else{
					$('#con_phone').addClass("invalid");
					error = true;
				}
			}
			if(order_email && filter_email.test(order_email)){
				
				$('#con_email').removeClass("invalid");
			}else{
		 		$('#con_email').addClass("invalid");
				error = true;
			}
			
			if ($( "#cnf" ).prop( "checked")){
				
				$('#cnf').parent("span").removeClass("invalid2");
			}else{
		 		$('#cnf').parent("span").addClass("invalid2");
				error = true;
			}
			
			if(!error){
			 
			var ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';
			
			var data = {
				'action' : 'wq_update_and_send_email',
				'order_id' : contact_id,
				'order_name' : order_name,
				'order_postcode' : order_postcode,
				'order_prefecture' : order_prefecture,
				'order_prefecture_text' : order_prefecture_text,
				'order_building' : order_building,
				'order_address' : order_address,
				'order_phone' : order_phone,
				'order_email' : order_email,
				'order_dday' : order_dday,
				'order_dtime' : order_dtime
			};
			
			jQuery.post(ajaxurl , data , function(response){
				//console.log(response);
				if(response==1){//checking badwords Exits or not
				
					jQuery('#show_mssg').show();				
					jQuery('#show_mssg').html('<font style="color: #56b93e;padding:5px;">Request has been sent successfully!</font>');	
					
					var url = '<?php echo $link;?>';
					window.location = url+'&contact-id='+contact_id;
					
					setTimeout(function() {
						jQuery("#show_mssg").hide(); 
						
					}, 8000);				
					
					document.getElementById("connectwithus").reset(); 
							
				}else{
				
					jQuery('#show_mssg').html('<font style="color:#d81616;padding:5px;">Request sent Fail.</font>');			
				}
				
			}); 	
	      }
		});
		
		// for each required input
		$(document).on('keyup','#con_name, #con_address, #con_phone, #con_email',function(){
			
			var val = $(this).val();
			if(val){
				$(this).removeClass("invalid");
			}else{
				$(this).addClass("invalid");
			}
		});
});
</script>
<style>
.invalid { 
	border: 1px solid red !important;
	border-color: red !important;
}
.invalid2 { 
	color: red !important;
}
</style>

