<?php
global $wpdb;

if(isset($_POST['settingsSaveWq'], $_POST['baseRates'])){
	
	update_option('baseRates', $_POST['baseRates']);
	update_option('terms_and_condition', $_POST['terms_and_cond']);
}

$baseRates = get_option('baseRates');
$terms_and_cond = get_option('terms_and_condition');
?>
<form action="" method="post">
    <h2>Settings</h2><br/>
    <?php /*?><label for="name" class="for_align">Carry In : </label>
    <input type="text" name="carryin" value="<?php echo $carryin; ?>" required="required" size="6" />
    <label for="name"> + Mac : </label>
    <input type="text" name="carryin_mac" value="<?php echo $carryin_mac; ?>" required="required" size="6" />
    <label for="name"> + Diagnostic : </label>
    <input type="text" name="carryin_dia" value="<?php echo $carryin_dia; ?>" required="required" size="6" />
    <br /><br />
    
    <label for="name" class="for_align">On site : </label>
    <input type="text" name="onsite" value="<?php echo $onsite; ?>" required="required" size="6" />
    <label for="name"> + Mac : </label>
    <input type="text" name="onsite_mac" value="<?php echo $onsite_mac; ?>" required="required" size="6" />
    <label for="name"> + Diagnostic : </label>
    <input type="text" name="onsite_dia" value="<?php echo $onsite_dia; ?>" required="required" size="6" />
    <br /><br /><?php */?>
    
    <label for="carryin" class="for_align">Carry In : </label>
    <input type="text" name="baseRates[carryin]" value="<?php echo $baseRates['carryin']; ?>" required="required" size="10" />
    <br /><br />
    
    <label for="onsite" class="for_align">On site : </label>
    <input type="text" name="baseRates[onsite]" value="<?php echo $baseRates['onsite']; ?>" required="required" size="10" />
    <br /><br />
    
    <label for="mac" class="for_align">Mac : </label>
    <input type="text" name="baseRates[mac]" value="<?php echo $baseRates['mac']; ?>" required="required" size="10" /> --> If it is mac then it will be added to the <b>carry in</b> or <b>onsite charge</b>.
    <br /><br />
    
    <label for="diagnostic" class="for_align">Diagnostic : </label>
    <input type="text" name="baseRates[diagnostic]" value="<?php echo $baseRates['diagnostic']; ?>" required="required" size="10" /> --> If it is mac then it will be added to the <b>carry in</b> or <b>onsite charge</b>.
    <br /><br />
    
    <label for="terms_and_cond" class="for_align">Terms and Condition : </label>
    <textarea name="terms_and_cond" required="required" /><?php echo $terms_and_cond; ?></textarea> Trems and Condition Of the Contact email Page.
    <br /><br />
    
    <input type="submit" name="settingsSaveWq" value="Save" class="button-primary">
</form>
<br />

<style>
.for_align{
	float:left;
	width: 31em;
	margin-right: -21em;
	text-align: left;
}
</style>