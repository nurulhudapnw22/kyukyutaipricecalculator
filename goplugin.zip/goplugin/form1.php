<link href="<?php echo FR_PLUGIN_URL; ?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo FR_PLUGIN_URL; ?>css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo FR_PLUGIN_URL; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700|Oswald:300,400,700" rel="stylesheet">
<?php $terms = get_terms( array(
				'taxonomy' => 'go-service-cat',
    			'hide_empty' => false,
				));
	
?>

<div class="container-fluid nopadd" ng-app="priceCalculatorApp" ng-controller="priceCalculatorCtrl">
  <div class="container width1">
    <div class="body-content">
      <div class="form">
        <div id="system-step" class="step1">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h1>You needs to specify your type of  computer?</h1>
              <select ng-model="computerType" class="form-control select-box-new" name="system_type">
              	<option ng-repeat="comp in computerTypes" value="{{comp.val}}">{{comp.label}}</option>
              </select>
            </div>
          </div>
        </div>
        <div id="service-category" class="step1 step2">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service Category:</h2>
              
              <select id="service-category-option" class="form-control select-box-new" >
                <option selected>-- Select --</option>
                <?php
                	foreach($terms as $key=>$term){
						$term_id = $term->term_id;
						$term_name = $term->name;
						$term_slug = $term->slug;
						if(!$term->parent){?>
							<option id="maintenance" class="category" value="<?php echo $term_id;?>"><?php echo $term_name;?></option>
						<?php }
					}
				?>
                <!--<option id="maintenance" value="maintainance">Maintenance</option>
                <option id="setup">Set up</option>
                <option id="trouble-repair">Trouble Repair</option>-->
              </select>
            </div>
          </div>
        </div>
        <div id="service-subcategory1" class="step1 step2">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service SubCategory:</h2>
              <select id="subcategory-option" class="form-control select-box-new-one width-auto">
                <option selected>-- Select --</option>
                <option id="subcat-new">Trouble Repair Support Pack</option>
                <option>Data Backup</option>
                <option>Data Migration</option>
              </select>
            </div>
          </div>
        </div>
        <div id="service-subcategory2" class="step1 step2">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service SubCategory:</h2>
              <select id="" class="form-control select-box-new-one width-auto">
                <option selected>-- Select --</option>
                <option>Pre-Network Setup</option>
                <option>IP Phone Setup</option>
                <option>LAN Setup</option>
                <option>Memory Setup</option>
                <option>Email/Browser Setup</option>
                <option>Internet Setup</option>
                <option>Network Setup</option>
                <option>Peripheral Setup</option>
                <option>Network Sharing Setup</option>
                <option>Security Camera Setup</option>
                <option>Computer Setup</option>
                <option>Setup Support Pack</option>
                <option>Backup Support Pack</option>
                <option>Application Setup</option>
                <option>Camera Setup</option>
              </select>
            </div>
          </div>
        </div>
        <div id="service-subcategory3" class="step1 step2">
          <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service SubCategory:</h2>
              <select id="" class="form-control select-box-new-one width-auto">
                <option selected>-- Select --</option>
                <option>Email Troubleshooting</option>
                <option>Network Troubleshooting</option>
                <option>Hardware Repair</option>
                <option>Harddisk Repair</option>
                <option>Windows</option>
                <option>Server Repair</option>
                <option>Data Deletion</option>
                <option>Power Repair</option>
                <option>Motherboard Repair</option>
                <option>Light Repair</option>
                <option>Peripheral Repair</option>
                <option>Power Repair</option>
                <option>Virus Repair</option>
                <option>Support Pack</option>
              </select>
            </div>
          </div>
        </div>
        <div id="service-category-two" class="step1 step2 text-center">
          <div class="diag-box">
            <div class="row text-center">
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box">
                  <h1>Diagnosis Not Needed</h1>
                  <div class="title-box">
                    <h3>Onsite</h3>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box">
                  <h1>Diagnosis Needed</h1>
                  <select id="" class="form-control select-box-new">
                    <option>Onsite</option>
                    <option>Carry In</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="diag-box nomrgnB">
            <h2 class="heading">Base Rate is <b>$2000</b></h2>
            <div class="step1 step2 text-center">
              <h2>Confirms Your Service</h2>
              <div class="select-list" id="service-name">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="select-label">
                      <input id="c1" name="logo-option" type="radio">
                      <label class="radio" for="c1"><span></span><b>Inspection Pack</b> - Outside and inside cleaning, inspection, hardware noise check, virus check, security updates. Inspection Pack - Outside and inside cleaning, inspection, hardware noise check, virus check, security updates.</label>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="select-label">
                      <input id="c2" name="logo-option" type="radio">
                      <label class="radio" for="c2"><span></span><b>Laptop Cleaning</b> - Dissasemble clean and assemble.</label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="service-category-four" class="step1 step2 text-center desc">
          <div class="diag-box">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box title-box-one">
                  <h1>Service Rate is $2000</h1>
                  <div class="service-cost-notes">
                    <p>serviceCostNotes will be here...</p>
                  </div>
                  <div class="price">Total Price: <span>$1999</span></div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box title-box-one">
                  <div class="service-cost-notes service-cost-notes2">
                    <p>serviceCostNotes will be here...</p>
                  </div>
                  <a href="#" class="call">03-5728-3576</a> </div>
              </div>
            </div>
          </div>
          <div class="step1 step2">
            <div class="row">
              <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
                <h2>Want to use our Service?</h2>
                <select id="service-select" class="form-control select-box-new">
                  <option>-- Select --</option>
                  <option value="" id="service-select-no">No</option>
                  <option value="http://webqueue.org/samples/projects/sudipta/BUILD-A-WORDPRESS-PLUGIN/html/contact-form.html">Yes</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div id="service-category-five" class="step1 step2 text-center desc">
          <div class="diag-box">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="txt-bx2">
                	<h3>goodbye</h3>
                    <h4>We hope to see you again.</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
<!--<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script> --> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/bootstrap.min.js" type="text/javascript"></script> 
<script src="<?php echo FR_PLUGIN_URL; ?>js/scripts.js"></script> 
<script>
var ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';
$(function() {
  $("#system-option").change(function() {
    if ($("#pc-form").is(":selected")) {
	//var pc_type = 'windows'; 
      $("#service-category").show();
      $("#client_graph_form").hide();
    } 
	/*if ($("#pc-mac").is(":selected")) {
		//var pc_type = 'mac'; 
      $("#service-category").show();
      $("#client_graph_form").hide();
    }*/
	else {
      $("#service-category").hide();
      $("#client_graph_form").show();
    }
  }).trigger('change');
  
});
$(function() {
  $("#customer-confirm-option").change(function() {
    if ($("#customer-confirm-no").is(":selected")) {
      $("#base-rate-no-box1").show();
    } else {
      $("#base-rate-no-box1").hide();
    }
  }).trigger('change');
  
});
$(function() {
  $("#customer-confirm-option").change(function() {
    if ($("#customer-confirm-yes").is(":selected")) {
      $("#base-rate-yes-box2").show();
    } else {
      $("#base-rate-yes-box2").hide();
    }
  }).trigger('change');
  
});
$(function() {
  $("#subcategory-option").change(function() {
    if ($("#subcat-new").is(":selected")) {
      $("#service-category-two").show();
    } else {
      $("#service-category-two").hide();
    }
  }).trigger('change');
  
});








$(function() {
  $("#service-select").change(function() {
    if ($("#service-select-no").is(":selected")) {
      $("#service-category-five").show();
    } else {
      $("#service-category-five").hide();
    }
  }).trigger('change');
  
});

$("#c1").click(function(){
    $("#service-category-four").show();
});


$(function() {
  $("#service-category-option").change(function() {	  
    
		var pc_type = $("#pc-form").val();
		var category = $(this).val();
		var data = {
			'action' : 'wq_create_pc_type_html',
			'pc_type' : pc_type,
			'category' : category
		};
		$.post(ajaxurl , data , function(response){
			console.log(response);
		});
		
      $("#service-subcategory1").show();
	/*if ($("#setup").is(":selected")) {
      $("#service-subcategory2").show();
    } else {
      $("#service-subcategory2").hide();
    }
	if ($("#trouble-repair").is(":selected")) {
	  $("#service-subcategory3").show();
    } else {
	  $("#service-subcategory3").hide();
    }*/
  })
  
  
  
  .trigger('change');
  
});
</script> 
<script>
    $(function(){
      // bind change event to select
      $('#service-select').on('change', function () {
          var url = $(this).val(); // get selected value
          if (url) { // require a URL
              window.location = url; // redirect
          }
          return false;
      });
    });
</script>

<script>
var app = angular.module('priceCalculatorApp', []);
app.controller('priceCalculatorCtrl', function($scope, $http) {
		
	$scope.total = 0;
	$scope.users = [];
	$scope.paged = 1;
	$scope.showLoadMore = true;
	
	$scope.computerTypes = [
		{val:'', label:'-- Select --'},
		{val:'pc', label:'PC(Windows)'},
		{val:'mac', label:'MAC'}
	];
	
	
	$scope.getPartners = function(data) {
		
		var religion = [];
		var mlang = [];
		
		$('input[name="religion[]"]:checked').each(function(index, element) {
			religion.push($(this).val());
		});
		$('input[name="mtongue[]"]:checked').each(function(index, element) {
			mlang.push($(this).val());
		});
		
		var data = {
			'paged': $scope.paged, 
			'gender': gender, 
			'ageFrom': ageFrom, 
			'ageTo': ageTo, 
			'religion[]': religion, 
			'mtongue[]': mlang
		};
		
        $http({
			method : "GET",
			url : "<?php echo home_url('/wp-json/tolgira/v1/partners'); ?>",
			params : data
		}).then(function(response) {
			if($scope.paged == 1){
				$scope.users = response.data.data;
			}else if(response.data.total){
				
				$scope.users = $scope.users.concat(response.data.data);
			}
			
			$scope.total = response.data.total;
			if($scope.users.length >= $scope.total){
				$scope.showLoadMore = false;
			}
		});
    };
	
	$scope.onClickCheckbox = function($event, val){
		
		$scope.paged = 1;
		$scope.getPartners();
	};
	
	$scope.onClickLoadMore = function($event){
		$scope.paged++;
		$scope.getPartners();
	};
	
	//for initial load
	//$scope.getPartners();
});
</script>
