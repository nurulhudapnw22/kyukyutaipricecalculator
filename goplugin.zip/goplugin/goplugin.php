<?php
/*
Plugin Name: GoPlugin
Plugin URI: http://www.webq.co.in/
Description: GoPlugin
Author: Webqueue Solutions
Author URI: http://www.webq.co.in/
*/

global $wpdb;
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php");
}

define( 'FR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'FR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

register_activation_hook( __FILE__, 'activate_fr_goplugin_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_fr_goplugin_plugin' );


require_once (FR_PLUGIN_DIR . '/functions/functions.php');
require_once (FR_PLUGIN_DIR . '/functions/ajax.php');
require_once (FR_PLUGIN_DIR . '/functions/shortcode.php');
//require_once (FR_PLUGIN_DIR . '/contact-form.php');
require_once ( FR_PLUGIN_DIR . 'admin-templates/feedback-list.php');
require_once ( FR_PLUGIN_DIR . 'admin-templates/order-list.php');

function activate_fr_goplugin_plugin(){
	
}

function deactivate_fr_goplugin_plugin(){
	// Uninstall code
}

/*add_action( 'wp_enqueue_scripts', 'wpb_adding_styles' ); 
function wpb_adding_styles() {

	wp_enqueue_style( 'theme-stylesheet', FR_PLUGIN_URL.'/css/style-wq.css' );
	//wp_enqueue_style( 'front-stylesheet', FR_PLUGIN_URL.'/css/style.css' );
		
}

*/
//custom Field Add Services Start
add_action( 'init', 'create_post_type_service' );

function create_post_type_service() {


 register_post_type( 'go-service',
   array(
    'labels' => array(
	'name' => __( 'Services' ),
	'singular_name' => __( 'Service' ),
	'rewrite' => true,
	'capability_type' => 'post',
	'hierarchical' => false,
	'menu_position' => null,
	),
     'public' => true,
     'has_archive' => true,

 'supports' => array( 'title', 'editor', 'thumbnail')

   )

 );

}
//custom Field Add Services End

/**
 * Add services custom meta fields
 */
function add_service_meta_boxes() {
	add_meta_box("services_field_meta", "Services field", "add_services_field_service_meta_box", "go-service", "normal", "low");
}
function add_services_field_service_meta_box()
{
	global $post;
	$custom = get_post_custom( $post->ID );
 
	?>
	<style>.width99 {width:99%;}</style>
	<p>
		<label><b>serviceID</b></label><br />
        <input type="text" name="service_id" value="<?= @$custom["service_id"][0] ?>" class="width99" />
	</p>
	<p>
		<label><b>Service Rate:</b></label><br />
		<input type="text" name="service_rate" value="<?= @$custom["service_rate"][0] ?>" class="width99" />
	</p>
	<p>
		<label><b>Service Cost Notes:</b></label><br />
		<textarea rows="5" name="service_cost_notes" class="width99"><?= @$custom["service_cost_notes"][0] ?></textarea>
	</p>
	<?php
}
/**
 * Save custom field data when creating/updating posts
 */
function save_service_custom_fields(){
  global $post;
 
  if ( $post )
  {
    update_post_meta($post->ID, "service_id", @$_POST["service_id"]);
    update_post_meta($post->ID, "service_rate", @$_POST["service_rate"]);
    update_post_meta($post->ID, "service_cost_notes", @$_POST["service_cost_notes"]);
  }
}
add_action( 'admin_init', 'add_service_meta_boxes' );
add_action( 'save_post', 'save_service_custom_fields' );

//Register taxonomy for Services Start
add_action( 'init', 'create_service_tax' );

function create_service_tax() {
	register_taxonomy(
		'go-service-cat',
		'go-service',
		array(
			'label' => __( 'Category' ),
			'rewrite' => array( 'slug' => 'go-service-cat' ),
			'hierarchical' => true,
		)
	);
} 

add_filter( 'manage_go-service_posts_columns', 'set_custom_edit_go_service_columns' );
function set_custom_edit_go_service_columns($columns) {
    
	//unset( $columns['author'] );
	
	$tcols = array();
	
	$tcols['cb'] = $columns['cb'];
	$tcols['title'] = $columns['title'];
	$tcols['category'] = __( 'Categories', 'go_text_domain' );
	$tcols['date'] = $columns['date'];
	
    return $tcols;
}

add_action( 'manage_go-service_posts_custom_column' , 'custom_go_service_column', 10, 2 );
function custom_go_service_column( $column, $post_id ) {
    switch ( $column ) {

        case 'category' :
            //$terms = get_the_term_list( $post_id , 'go-service-cat' , '' , ', ' , '' );
			$term_list = wp_get_post_terms($post_id, 'go-service-cat', array('orderby' => 'term_id', 'order' => 'ASC', "fields" => "all"));
			$terms = array();
			foreach($term_list as $term_single) {
				$terms[] = $term_single->name; //do something here
			}
			
			if($terms){
				echo implode(", " , $terms);
			}
            break;

    }
}
//Register taxonomy for Services End

// Hide page editor of Sercice Post type
/*add_action('init', 'init_remove_support',100);
function init_remove_support(){
    $post_type = 'go_service';
    remove_post_type_support( $post_type, 'editor');
}*/
/////////////////////////////////


//add settings submenu page


function go_register_custom_submenu_page(){
	
	add_submenu_page('edit.php?post_type=go-service', __('Settings','menu-test'), __('Settings','menu-test'), 'manage_options', 'settings', 'go_settings_page');
		
	add_submenu_page('edit.php?post_type=go-service', __('Feedbacks','menu-test'), __('Feedbacks','menu-test'), 'manage_options', 'feedbacks', 'feedbackListPageMenu');
	
	$order_menu_hook = add_submenu_page('edit.php?post_type=go-service', __('Orders','menu-test'), __('Orders','menu-test'), 'manage_options', 'go-orders', 'goOrderListPageMenu');
	
	add_action( "load-".$order_menu_hook, 'goOrderListPageMenu_optionReservationDetails' );
}

//FOR SCREEN OPTION START
function goOrderListPageMenu_optionReservationDetails() {
	
  $option = 'per_page';
  $args = array(
         'label' => 'Number of items per page:',
         'default' => 10,
         'option' => 'orders_per_page'
         );
  add_screen_option( $option, $args );
  $myListTable = new OrderList;
}

/*add_filter('set-screen-option', 'tr_reservation_table_set_option', 10, 3);
function tr_reservation_table_set_option($status, $option, $value) {

  return $value;
}*/
//FOR SCREEN OPTION END

function go_settings_page(){
	
	require_once (FR_PLUGIN_DIR . '/admin-templates/settings.php');
}

add_action('admin_menu', 'go_register_custom_submenu_page');

/*  Custom Field for Categories.
    ======================================== */

// Add new term page
function wq_go_taxonowq_go_add_meta_fields( $taxonowq_go ) { ?>
    <div class="form-field term-group">
        <label for="excludefrommac">
          <?php _e( 'Exclude from mac', 'codilight-lite' ); ?> <input type="checkbox" id="excludefrommac" name="excludefrommac" value="yes" />
        </label>
        <label for="needs_diagnosis">
          <?php _e( 'Needs Diagnosis', 'codilight-lite' ); ?> <input type="checkbox" id="needs_diagnosis" name="needs_diagnosis" value="yes" />
        </label>
    </div><?php
}
//add_action( 'go-service-cat_add_form_fields', 'wq_go_taxonowq_go_add_meta_fields', 10, 2 );

// Edit term page
function wq_go_taxonowq_go_edit_meta_fields( $term, $taxonowq_go ) {
    $excludefrommac = get_term_meta( $term->term_id, 'excludefrommac', true ); 
	$needs_diagnosis = get_term_meta( $term->term_id, 'needs_diagnosis', true ); 
	$carry_in = get_term_meta( $term->term_id, 'carry_in', true );
	$on_site = get_term_meta( $term->term_id, 'on_site', true ); 
	
	
	if($term->parent){
	?>

    <tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="excludefrommac"><?php _e( 'Exclude from mac', 'codilight-lite' ); ?></label>
        </th>
        <td>
        <input type="checkbox" id="excludefrommac" name="excludefrommac" value="yes" <?php echo ( $excludefrommac ) ? checked( $excludefrommac, 'yes' ) : ''; ?>/>
        </td>
    </tr>
	<tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="needs_diagnosis"><?php _e( 'Needs Diagnosis', 'codilight-lite' ); ?></label>
        </th>
        <td>
        <input type="checkbox" id="needs_diagnosis" class="needs-diagnosis-check" name="needs_diagnosis" value="yes" <?php echo ( $needs_diagnosis ) ? checked( $needs_diagnosis, 'yes' ) : ''; ?> />
        </td>
    </tr>
    <tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="carry_in"><?php _e( 'Carry In', 'codilight-lite' ); ?></label>
        </th>
        <td>
        <input type="checkbox" id="carry_in" class="carry-in-check" name="carry_in" value="yes" <?php echo ( $carry_in ) ? checked( $carry_in, 'yes' ) : ''; ?> <?php if($needs_diagnosis != 'yes') echo 'disabled="true"'; ?> />
        </td>
    </tr>
    <tr class="form-field term-group-wrap">
        <th scope="row">
            <label for="on_site"><?php _e( 'On Site', 'codilight-lite' ); ?></label>
        </th>
        <td>
        <input type="checkbox" id="on_site" class="on-site-check" name="on_site" value="yes" <?php echo ( $on_site ) ? checked( $on_site, 'yes' ) : ''; ?>/>
        </td>
    </tr>
    
    <script type="text/javascript">
	jQuery(document).ready(function($) {
        
		//$('.carry-in-check').prop('disabled', true);
		//$('.on-site-check').prop('disabled', true);
		
		/*$('.needs-diagnosis-check').on('change', function(){
			if($(".needs-diagnosis-check").prop('checked') == true){
				$('.carry-in-check').prop('disabled', false);
				$('.on-site-check').prop('disabled', false);
				$('.carry-in-check').on('change', function(){
					if($(".carry-in-check").prop('checked') == true){
						$('.on-site-check').prop('disabled', true);
					}else{
						$('.on-site-check').prop('disabled', false);
					}
				});
				$('.on-site-check').on('change', function(){
					if($(".on-site-check").prop('checked') == true){
						$('.carry-in-check').prop('disabled', true);
					}else{
						$('.carry-in-check').prop('disabled', false);
					}
				});
			}else {
				$('.carry-in-check').prop('disabled', true);
				$('.on-site-check').prop('disabled', true);
			}
		});*/
		
		$('.needs-diagnosis-check').on('change', function(){
			if($(".needs-diagnosis-check").prop('checked') == true){
				$('.carry-in-check').prop('disabled', false);
			}else {
				$('.carry-in-check').prop('disabled', true);
			}
		});
		
    });
	</script>
	<?php
	}
}
add_action( 'go-service-cat_edit_form_fields', 'wq_go_taxonowq_go_edit_meta_fields', 10, 2 );

// Save custom meta
function wq_go_taxonowq_go_save_taxonowq_go_meta( $term_id, $tag_id ) {
    if ( isset( $_POST[ 'excludefrommac' ] ) ) {
        update_term_meta( $term_id, 'excludefrommac', 'yes' );
    } else {
        update_term_meta( $term_id, 'excludefrommac', 'no' );
    }
	
	if ( isset( $_POST[ 'needs_diagnosis' ] ) ) {
        update_term_meta( $term_id, 'needs_diagnosis', 'yes' );
    } else {
        update_term_meta( $term_id, 'needs_diagnosis', 'no' );
    }
	
	if ( isset( $_POST[ 'carry_in' ] ) ) {
        update_term_meta( $term_id, 'carry_in', 'yes' );
    } else {
        update_term_meta( $term_id, 'carry_in', 'no' );
    }
	
	if ( isset( $_POST[ 'on_site' ] ) ) {
        update_term_meta( $term_id, 'on_site', 'yes' );
    } else {
        update_term_meta( $term_id, 'on_site', 'no' );
    }
}
add_action( 'created_go-service-cat', 'wq_go_taxonowq_go_save_taxonowq_go_meta', 10, 2 );
add_action( 'edited_go-service-cat', 'wq_go_taxonowq_go_save_taxonowq_go_meta', 10, 2 );