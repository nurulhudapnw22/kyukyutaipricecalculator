<?php 
add_shortcode( 'go', 'create_go_button' );

function create_go_button($atts) {
	
	ob_start();
	
	$atts = shortcode_atts( array(
		'link' => ''
	), $atts, 'go' );	
	
	$link = add_query_arg( 'go-step', 2, $atts['link']);
	
	echo '<a href="'.$link.'" class="go-btn">Go</a>';
	
	return ob_get_clean();
}

add_shortcode( 'price-calculator', 'create_price_calculator' );

function create_price_calculator($atts) {
	
	ob_start();
	
	/*$atts = shortcode_atts( array(
		'link' => ''
	), $atts, 'go' );	*/
	
	$step = (isset($_GET['go-step']) && $_GET['go-step'] && intval($_GET['go-step']) > 1) ? intval($_GET['go-step']) : 1;
	$link = add_query_arg( 'go-step', ($step + 1), get_permalink());
	
	switch($step){
		
		case 2 :
		{
			require_once ( FR_PLUGIN_DIR . '/form.php');
		}
		break;
		
		case 3 :
		{
			require_once ( FR_PLUGIN_DIR . '/contact-form.php' );
		}
		break;
		
		case 4 :
		{
			require_once ( FR_PLUGIN_DIR . '/customer-feedback.php' );
		}
		break;
		
		default:
			echo '<a href="'.$link.'" class="go-btn">Go</a>';
			
			break;
	}
	
	
	return ob_get_clean();
}

/*add_shortcode( 'price-calculator', 'create_price_calculator' );

function create_price_calculator($atts) {
	ob_start();
	require_once ( FR_PLUGIN_DIR . '/form.php');
	return ob_get_clean();
}

add_shortcode( 'confirm_contact', 'send_mail_from_client' );

function send_mail_from_client($atts) {
	ob_start();
	require_once ( FR_PLUGIN_DIR . '/contact-form.php');
	return ob_get_clean();
}*/