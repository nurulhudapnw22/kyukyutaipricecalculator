<?php
add_action( 'wp_ajax_wq_create_subcategory_html', 'wq_create_subcategory_html' );
add_action( 'wp_ajax_nopriv_wq_create_subcategory_html', 'wq_create_subcategory_html' );

function wq_create_subcategory_html() {
	global $wpdb;
	$pc_type = $_POST['pc_type'];
	$category_id = $_POST['category'];
	ob_start(); ?>
		 <div class="row">
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
              <h2>Please Confirms your Service SubCategory:</h2>
			  <?php 
				 //$terms = get_term_children( $category_id, 'go-service-cat' );
				 /*$terms = get_terms( 'go-service-cat', array(
					'hide_empty' => true,
					'parent' => $category_id,
				) );*/
				
				$args = array(
					'hide_empty' => true,
					'parent' => $category_id,
				);
				
				if($pc_type == 'mac'){
					$args['meta_query'] =  array(
						 array(
							'key'       => 'excludefrommac',
							'value'     => "yes",
							'compare'   => '!='
						 )
					);
				}
				
				$terms = get_terms( 'go-service-cat', $args);
			  ?>
              <select id="subcategory-option" class="form-control select-box-new-one width-auto">
                <option selected>-- Select --</option>
				<?php 
				foreach($terms as $term){
				?>
                <option id="subcat-new" class="subcategory1" value="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
				<?php }?>
              </select>
            </div>
          </div>
	<?php
	$html = ob_get_clean();
	echo $html;
	die();
}

add_action( 'wp_ajax_wq_create_service_confirm_html', 'wq_create_service_confirm_html' );
add_action( 'wp_ajax_nopriv_wq_create_service_confirm_html', 'wq_create_service_confirm_html' );

function wq_create_service_confirm_html() {
	global $wpdb;
	$pc_type = $_POST['pc_type'];
	$category_id = $_POST['category'];
	$sub_category_id = $_POST['sub_category'];
	$sub_cat_det = get_term_meta($sub_category_id);
	$is_pc = $sub_cat_det['excludefrommac'][0];
	$needs_diagnosis = $sub_cat_det['needs_diagnosis'][0];
	$carry_in = $sub_cat_det['carry_in'][0];
	$on_site = $sub_cat_det['on_site'][0];
	ob_start();
	
	$baseRates = get_option('baseRates');
	
	$baserate = 0;
	
	if($pc_type == 'mac'){
		$baserate += $baseRates['mac'];
	}
	
	if($needs_diagnosis=="yes"){
		$baserate += $baseRates['diagnostic'];
	}
	
	?>
      
          <div class="diag-box">
            <div class="row text-center">
            <?php if($needs_diagnosis=="no"){?>
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box">
                  <h1>Diagnosis Not Needed</h1>
                  <div class="title-box">
                    <h3>Onsite</h3>
                  </div>
                </div>
              </div>
              <?php }
			  if($needs_diagnosis=="yes"){
			  ?>
              <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
                <div class="title-box">
                  <h1>Diagnosis Needed</h1>
                  <select id="onsite_carryin_select" class="form-control select-box-new">
                    <option value="onsite">Onsite</option>
                    <option value="carryin">Carry In</option>
                  </select>
                </div>
              </div>
              <?php }?>
            </div>
          </div>
          <div class="diag-box nomrgnB">
            <h2 id="onsite_baserate" class="heading ocbaserate">Base Rate is <b>￥<?php echo $baserate + $baseRates['onsite']; ?></b></h2>
            <h2 id="carryin_baserate" class="heading ocbaserate" style="display:none;">Base Rate is <b>￥<?php echo $baserate + $baseRates['carryin']; ?></b></h2>
            <div class="step1 step2 text-center">
              <h2>Confirms Your Service</h2>
              <div class="select-list" id="service-name">
                <div class="row">
                	<?php
					$args = array(
						'post_type' => 'go-service',
						'post_status' => 'publish',
						'posts_per_page' => -1,
						'tax_query' => array(
							array(
								'taxonomy' => 'go-service-cat',
								'field'    => 'term_id',
								'terms'    => $sub_category_id,
							),
						),
					);
					$the_query = new WP_Query( $args );
					
					if ( $the_query->have_posts() ) {
						while ( $the_query->have_posts() ) {
							$the_query->the_post();
							
							?>
                            <div class="col-lg-12">
                                <div class="select-label">
                                  <input class="logo-option-post-list" value="<?php echo get_the_ID();?>" id="c<?php echo get_the_ID();?>" name="logo-option" type="radio">
                                  <label class="radio" for="c<?php echo get_the_ID();?>"><span></span><b><?php the_title(); ?></b> - <?php echo get_the_content(); ?></label>
                                </div>
                              </div>
                            
                            <?php
						}
						/* Restore original Post Data */
						wp_reset_postdata();
					}
					?>
                  
                </div>
              </div>
            </div>
          </div>
        
	<?php
	$html = ob_get_clean();
	echo $html;
	die();
}

add_action( 'wp_ajax_wq_onselect_post_html', 'wq_onselect_post_html_callback' );
add_action( 'wp_ajax_nopriv_wq_onselect_post_html', 'wq_onselect_post_html_callback' );

function wq_onselect_post_html_callback(){
	
	global $wpdb;
	$pc_type = $_POST['pc_type'];
	$category_id = $_POST['category'];
	$sub_category_id = $_POST['sub_category'];
	$sub_cat_det = get_term_meta($sub_category_id);
	$is_pc = $sub_cat_det['excludefrommac'][0];
	$needs_diagnosis = $sub_cat_det['needs_diagnosis'][0];
	$carry_in = $sub_cat_det['carry_in'][0];
	$on_site = $sub_cat_det['on_site'][0];
	$post_id = $_POST['post_id'];
	$carryin_onsite = $_POST['carryin_onsite'];
	
	ob_start();
	
	$baseRates = get_option('baseRates');
	
	$baserate = 0;
	
	if($carryin_onsite == 'carryin'){
		$baserate += $baseRates['carryin'];
	}else{
		$baserate += $baseRates['onsite'];
	}
	
	if($pc_type == 'mac'){
		$baserate += $baseRates['mac'];
	}
	
	if($needs_diagnosis=="yes"){
		$baserate += $baseRates['diagnostic'];
	}
	
	$service_rate = get_post_meta($post_id, 'service_rate', true);
	$service_cost_notes = get_post_meta($post_id, 'service_cost_notes', true);
	?>
    
      <div class="diag-box">
        <div class="row">
        <?php if($service_rate){?>
          <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
            <div class="title-box title-box-one">
              <h1>Service Rate is ￥<?php echo $service_rate;?></h1>
              <?php if($service_cost_notes) {?>
              <div class="service-cost-notes">
                <p><?php echo $service_cost_notes; ?></p>
              </div>
              <?php }?>
              <div class="price">Total Price: <span>￥<?php echo $baserate+$service_rate;?></span></div>
            </div>
          </div>
          <?php } else{ ?>
          <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 mid-column-inline">
            <div class="title-box title-box-one">
              
              <?php if($service_cost_notes) {?>
              <div class="service-cost-notes service-cost-notes2">
                <p><?php echo $service_cost_notes; ?></p>
              </div>
              <?php }?>
              <a href="#" class="call">03-5728-3576</a> </div>
          </div>
          <?php }?>
        </div>
      </div>
      <?php if($service_rate){?>
      <div class="step1 step2">
        <div class="row">
          <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12 mid-column text-center">
            <h2>Want to use our Service?</h2>
            <select id="service-select" class="form-control select-box-new">
              <option>-- Select --</option>
              <option value="no">No</option>
              <option value="yes">Yes</option>
            </select>
          </div>
        </div>
      </div>
      <?php }?>
    <?php
	die();
}

add_action( 'wp_ajax_wq_save_data_before_email', 'wq_save_data_before_email' );
add_action( 'wp_ajax_nopriv_wq_save_data_before_email', 'wq_save_data_before_email' );

function wq_save_data_before_email(){
	
	global $wpdb;
	$table_name = $wpdb->prefix ."savecontactdata";
	$pc_type = $_POST['pc_type'];
	$category_id = $_POST['category'];
	$sub_category_id = $_POST['sub_category'];
	$sub_cat_det = get_term_meta($sub_category_id);
	$needs_diagnosis = $sub_cat_det['needs_diagnosis'][0];
	$carryin_onsite = $_POST['service_type_name'];
	$service_id = $_POST['service_name'];
	//$service_name = get_the_title($service_id);
	$baseRates = get_option('baseRates');
	
	$baserate = 0;
	
	if($carryin_onsite == 'carryin'){
		$baserate += $baseRates['carryin'];
	}else{
		$baserate += $baseRates['onsite'];
	}
	
	if($pc_type == 'mac'){
		$baserate += $baseRates['mac'];
	}
	
	if($needs_diagnosis=="yes"){
		$baserate += $baseRates['diagnostic'];
	}
	
	$service_rate = get_post_meta($service_id, 'service_rate', true);
	$total_rate = $baserate+$service_rate;
	
	$insert = $wpdb->insert($table_name, 
				array(
					'pc_type' => $pc_type, 
					'category_id' => $category_id, 
					'sub_category_id' => $sub_category_id, 
					'needs_diagnosis' => $needs_diagnosis, 
					'carryin_onsite' => $carryin_onsite, 
					'service_id' => $service_id, 
					'baserate' => $baserate, 
					'service_rate' => $service_rate, 
					'total_rate' => $total_rate) );	
	$lastid = $wpdb->insert_id;
	if($insert){
		echo $lastid;
	}
	die();
}

add_action( 'wp_ajax_wq_update_and_send_email', 'wq_update_and_send_email' );
add_action( 'wp_ajax_nopriv_wq_update_and_send_email', 'wq_update_and_send_email' );

function wq_update_and_send_email(){
	
	global $wpdb;
	$table_name = $wpdb->prefix ."savecontactdata";
	$order_id = $_POST['order_id'];
	$order_name = $_POST['order_name'];
	$order_postcode = $_POST['order_postcode'];
	$order_prefecture = $_POST['order_prefecture'];
	$order_prefecture_text = $_POST['order_prefecture_text'];
	$order_building = $_POST['order_building'];
	$order_address = $_POST['order_address'];
	$order_phone = $_POST['order_phone'];
	$order_email = $_POST['order_email'];
	$order_dday = $_POST['order_dday'];
	$order_dtime = $_POST['order_dtime'];
	$retrieve_data = $wpdb->get_results( "SELECT * FROM $table_name where `id`=$order_id" );
	//print_r($retrieve_data[0]->pc_type);
	$data = $retrieve_data[0];
	$pc_type = $data->pc_type;
	$category_id = $data->category_id;
	$category_name = get_term($category_id)->name;
	$sub_category_id = $data->sub_category_id;
	$sub_category_name = get_term($sub_category_id)->name;
	$needs_diagnosis = $data->needs_diagnosis;
	$carryin_onsite = $data->carryin_onsite;
	$service_id = $data->service_id;
	$service_name = get_the_title($service_id);
	$baserate = $data->baserate;
	$service_rate = $data->service_rate;
	$total_rate = $data->total_rate;
	$update = $wpdb->update($table_name, 
				 array(
						'contact_name' => $order_name,
						'contact_postcode' => $order_postcode,
						'contact_prefecture' => $order_prefecture,
						'contact_building' => $order_building,
						'contact_address' => $order_address,
						'contact_phone' => $order_phone,
						'contact_email' => $order_email,
						'desired_date' => $order_dday,
						'desired_time' => $order_dtime
					),
					array( 
						'id'    => $order_id
					)
				);
		if($update){
			$to = get_option('admin_email');
			$from = $order_email;
			ob_start(); ?>
      
                    <table>
                        <tr>
                            <td><b>Name</b></td>
                            <td><label><?php echo $order_name;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Email ID</b></td>
                            <td><label><?php echo $order_email;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Postcode</b></td>
                            <td><label><?php echo $order_postcode;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Prefecture</b></td>
                            <td><label><?php echo $order_prefecture_text;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Building</b></td>
                            <td><label><?php echo $order_building;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Address</b></td>
                            <td><label><?php echo $order_address;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Phone</b></td>
                            <td><label><?php echo $order_phone;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Desired Time</b></td>
                            <td><label><?php echo $order_dtime;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Desired Day</b></td>
                            <td><label><?php echo $order_dday;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Category Name</b></td>
                            <td><label><?php echo $category_name;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Sub-Category Name</b></td>
                            <td><label><?php echo $sub_category_name;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Needs Diagonosis</b></td>
                            <td><label><?php echo ucfirst($needs_diagnosis);?></label></td>
                        </tr>
                        <tr>
                            <td><b>Service Type</b></td>
                            <td><label><?php echo ucfirst($carryin_onsite);?></label></td>
                        </tr>
                        <tr>
                            <td><b>Service Name</b></td>
                            <td><label><?php echo $service_name;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Base Rate</b></td>
                            <td><label><?php echo $baserate;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Service Rate</b></td>
                            <td><label><?php echo $service_rate;?></label></td>
                        </tr>
                        <tr>
                            <td><b>Total Rate</b></td>
                            <td><label><?php echo $total_rate;?></label></td>
                        </tr>
                    </table>
             		
			<?php
			$html = ob_get_clean(); 
			wq_mail_send($to, $from, $subject, $html);
			echo 1;
		}
		
		die();
}

add_action( 'wp_ajax_wq_give_feedback_from_client', 'wq_give_feedback_from_client' );
add_action( 'wp_ajax_nopriv_wq_give_feedback_from_client', 'wq_give_feedback_from_client' );
function wq_give_feedback_from_client(){
	
	global $wpdb;
	$table_name = $wpdb->prefix ."feedback";
	$feedback_name = $_POST['feedback_name'];
	$feedback_email = $_POST['feedback_email'];
	$feedback_where_val = $_POST['feedback_where_val'];
	$feedback_where_text = $_POST['feedback_where_text'];
	$feedback_note = $_POST['feedback_note'];
	$contact_id = $_POST['contact_id'];
	
	$insert = $wpdb->insert($table_name, 
				array(
					'feedback_name' => $feedback_name, 
					'feedback_email' => $feedback_email, 
					'feedback_where' => $feedback_where_val, 
					'feedback_note' => $feedback_note,
					'feedback_user_id' => $contact_id) );	
	if($insert){
		$to = get_option('admin_email');
		$from = $feedback_email;
			ob_start(); ?>
                <table>
                    <tr>
                        <td><b>Name</b></td>
                        <td><label><?php echo $feedback_name;?></label></td>
                    </tr>
                    <tr>
                        <td><b>Email ID</b></td>
                        <td><label><?php echo $feedback_email;?></label></td>
                    </tr>
                    <tr>
                        <td><b>From Where</b></td>
                        <td><label><?php echo ucfirst($feedback_where_val);?></label></td>
                    </tr>
                    <tr>
                        <td><b>Feedback</b></td>
                        <td><label><?php echo $feedback_note;?></label></td>
                    </tr>
                  </table>
			<?php
			$html = ob_get_clean(); 
			wq_mail_send($to, $from, $subject, $html);
			echo 1;
		//echo 1;
	}
	die();
	
}


function wq_mail_send($to="",$from="", $subject="", $meaasge=""){
	if(!empty($to) && !empty($meaasge)){
		// Always set content-type when sending HTML email
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		
		// More headers
		//$from = $from;
		if(!empty($from)){
			$headers .= 'From: <'.$from.'>' . "\r\n";
		}
		//$headers .= 'Cc: myboss@example.com' . "\r\n";
		
		return mail($to,$subject,$meaasge,$headers);
		
	}else{
		return false;
	}
}