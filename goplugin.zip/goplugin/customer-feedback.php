<link href="<?php echo FR_PLUGIN_URL; ?>css/style-webq.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Raleway:400,600,700" rel="stylesheet">
<div class="wq_main center-textwq">
<div class="wq_center_wrap">
<div class="wq_main inner-wrapwq lefttext-wq">
<div class="common-wrapwq titlewq-top">
<h1>Customer Feedback</h1>
<p>(Please write about the experience working with us.）</p>
</div>
<div class="common-wrapwq form-wq">
<div class="halfdivwq left-pullwq">
<form id="givefeedbackus" method="post">
<label class="labelwq">Name</label>
<input name="" type="text" class="input-wq" id="feedback_name" placeholder="Enter name" required>
</div>
<div class="halfdivwq right-pullwq">
<label class="labelwq">Email</label>
<input name="" type="text" class="input-wq" id="feedback_email" placeholder="Enter email" required>
</div>
<div class="fulldivwq left-pullwq">
<label class="labelwq">From where you find the application</label>
<select class="input-wq" id="feedback_where" required>
<option selected>Choose</option>
<option value="option1">Option 1</option>
<option value="option2">Option 2</option>
<option value="option3">Option 3</option>
<option value="option4">Option 4</option>
</select>
</div>
<div class="fulldivwq left-pullwq">
<label class="labelwq">Write your feedback</label>
<textarea name="" cols="" rows="" class="input-wq wq_teaxtarea" id="feedback_note" placeholder="Please write here..."></textarea>
</div>

<div class="fulldivwq left-pullwq">
<button type="submit" class="submitwq feedback_submit">Submit Now</button>
<div id="show_mssg"> </div>
</form>
</div>
</div>
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script type="text/javascript">
	$(document).ready(function(){
		var feedback_name 	= $('#feedback_name').val(); 
		var feedback_email 	= $('#feedback_email').val(); 
		var feedback_where_val  = $("#feedback_where option:selected").val();
	    var feedback_where_text= $("#feedback_where option:selected").text();
		var feedback_note 	= $('#feedback_note').val();
		var contact_id		= '<?php echo $_GET['contact-id'];?>';
		
		var filter_email 	= /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var error = false;
		$(document).on('submit','#givefeedbackus',function(e){
			e.preventDefault();
			
			feedback_name 	= $('#feedback_name').val(); 
			feedback_email 	= $('#feedback_email').val();
			feedback_where_val  = $("#feedback_where option:selected").val(); 
			feedback_where_text= $("#feedback_where option:selected").text();
			var feedback_note 	= $('#feedback_note').val();
			//console.log(feedback_where_val);
			if(feedback_name){
				 $('#feedback_name').removeClass("invalid");
			}else{
			   $('#feedback_name').addClass("invalid");
			   error = true;
			}
			if(feedback_email && filter_email.test(feedback_email)){
				
				$('#feedback_email').removeClass("invalid");
			}else{
		 		$('#feedback_email').addClass("invalid");
				error = true;
			}
			if(!error){
				var ajaxurl = '<?php echo admin_url('admin-ajax.php');?>';
				var data = {
					'action' : 'wq_give_feedback_from_client',
					'feedback_name' : feedback_name,
					'feedback_email' : feedback_email,
					'feedback_where_val' : feedback_where_val,
					'feedback_where_text' : feedback_where_text,
					'feedback_note' : feedback_note,
					'contact_id' : contact_id,
				};
				jQuery.post(ajaxurl , data , function(response){
					console.log(response);
					if(response==1){//checking badwords Exits or not
					
						jQuery('#show_mssg').show();				
						jQuery('#show_mssg').html('<font style="color: #56b93e;padding:5px;">Feedback has been sent successfully!</font>');	
						
						setTimeout(function() {
							jQuery("#show_mssg").hide(); 
							
						}, 8000);				
						
						document.getElementById("givefeedbackus").reset(); 
								
					}else{
					
						jQuery('#show_mssg').html('<font style="color:#d81616;padding:5px;">Feedback sent Fail.</font>');			
					}
					
				}); 
			}
		});
		$(document).on('keyup','#feedback_name, #feedback_email',function(){
			
			var val = $(this).val();
			if(val){
				$(this).removeClass("invalid");
			}else{
				$(this).addClass("invalid");
			}
		}); 
	});
</script>
<style>
.invalid { 
	border: 1px solid red !important;
	border-color: red !important;
}
</style>
